package com.picovr.vr.ui.util;

/**
 * Created by zhisheng on 2016/6/7.
 */
public interface ViewEvent {
    public abstract void onFocus(boolean focus);
}

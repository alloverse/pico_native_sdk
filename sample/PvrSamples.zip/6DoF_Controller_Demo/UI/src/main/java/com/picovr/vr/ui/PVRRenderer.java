package com.picovr.vr.ui;

import android.content.Context;

import org.rajawali3d.vr.renderer.VRRenderer;

/**
 * Created by yhc on 16-7-14.
 */
public abstract class PVRRenderer extends VRRenderer {

    public PVRRenderer(Context context) {
        super(context);
    }

}

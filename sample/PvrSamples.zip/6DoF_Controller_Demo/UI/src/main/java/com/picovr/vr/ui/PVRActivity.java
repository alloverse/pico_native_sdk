package com.picovr.vr.ui;

import org.rajawali3d.vr.VRActivity;

/**
 * Created by yhc on 16-7-14.
 */
public class PVRActivity extends VRActivity {
}

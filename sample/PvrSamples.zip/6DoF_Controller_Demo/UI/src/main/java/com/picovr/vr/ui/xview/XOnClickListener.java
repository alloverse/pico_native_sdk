package com.picovr.vr.ui.xview;

/**
 * Created by jeffrey.liu on 2017/6/26.
 */

public interface XOnClickListener {

    boolean onClick(XView view);
}

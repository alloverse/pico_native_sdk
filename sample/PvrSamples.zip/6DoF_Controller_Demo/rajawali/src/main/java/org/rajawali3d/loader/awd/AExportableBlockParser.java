package org.rajawali3d.loader.awd;

public abstract class AExportableBlockParser extends ABaseObjectBlockParser {

}

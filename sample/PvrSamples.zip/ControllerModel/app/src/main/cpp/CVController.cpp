//
// Created by Administrator on 2019/11/7.
//
#include <utils/logUtil.h>
#include "CVController.h"
#include "ControllerModel.h"

ControllerManager* ControllerManager::mInstance = nullptr;

CVController::CVController() {
    ctrModel = new ControllerModel(this);
}

void CVController::init() {
    connect = false;
    ctrModel->init();
}

void CVController::release() {
    ctrModel->release();
}

void CVController::setData(float *ori, float *pos) {
    LOGI("setData %f %f %f %f , %f %f %f",
            ori[0],
            ori[1],
            ori[2],
            ori[3],
            pos[0],
            pos[1],
            pos[2]
    );
    if(ori != nullptr){
        orientation = glm::fquat(ori[3],ori[0],ori[1],-ori[2]);
    }

    if(pos != nullptr){
        position = glm::vec3(pos[0],pos[1],pos[2]);
    }

    rayPoint = (glm::vec3(0.0f,0.0f,-10.0f) * orientation)+position;

}
void CVController::setHmdSensor(pvrPosef sensor) {
    LOGI("setHmdSensor %f %f %f %f , %f %f %f",
            sensor.Orientation.w,
            sensor.Orientation.x,
            sensor.Orientation.y,
            sensor.Orientation.z,
            sensor.Position.x,
            sensor.Position.y,
            sensor.Position.z
            );
    mHMD = sensor;
}
glm::mat4 CVController::getMatrix(){
    float w = orientation.w;
    float x = orientation.x;
    float y = orientation.y;
    float z = orientation.z;

    float px = position.x;
    float py = position.y;
    float pz = position.z;

    LOGI("GetModelMatrix %f %f %f %f ，%f %f %f ",w,x,y,z,px,py,pz);

    float ww = w * w;
    float xx = x * x;
    float yy = y * y;
    float zz = z * z;
    glm::mat4 M;
    M[0][0] = ww + xx - yy - zz;       M[0][1] = 2 * ( x * y - w * z );    M[0][2] = 2 * ( x * z + w * y );    M[0][3] = 0.f;
    M[1][0] = 2 * ( x * y + w * z );   M[1][1] = ww - xx + yy - zz;        M[1][2] = 2 * ( y * z - w * x );    M[1][3] = 0.f;
    M[2][0] = 2 * ( x * z - w * y );   M[2][1] = 2 * ( y * z + w * x );    M[2][2] = ww - xx - yy + zz;        M[2][3] = 0.f;
    M[3][0] = px;                      M[3][1] = py;                       M[3][2] = pz;                       M[3][3] = 1.f;

    return M;
}

CVController::~CVController() {

}

ControllerManager::ControllerManager() {
    controllers = new CVController[2];
    controllers[0].serialNum = 0;
    controllers[1].serialNum = 1;
    memset(externalFiles,0, 1024*sizeof(char));
}

void ControllerManager::initAll() {
    controllers[0].init();
    controllers[1].init();
}

void ControllerManager::releaseAll() {
    controllers[0].release();
    controllers[1].release();
}

void ControllerManager::drawAll(int eye) {
    LOGI("ControllerManager::drawAll %d, %d",controllers[0].connect,controllers[1].connect);
    glClearColor(0.0f,0.0f,0.0f,0.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    if (controllers[0].connect){
        controllers[0].ctrModel->draw(eye);
    }

    if (controllers[1].connect){
        controllers[1].ctrModel->draw(eye);
    }
}

void ControllerManager::updateHMD(pvrPosef* hmd){
    pvrPosef copy = *hmd;
    if (controllers[0].connect){
        controllers[0].setHmdSensor(copy);
    }
    if (controllers[1].connect){
        controllers[1].setHmdSensor(copy);
    }
}

void ControllerManager::setData(int serialNum, float *ori, float *pos) {
    if (serialNum!=0&&serialNum!=1) {
        LOGE("ControllerManager::setData wrong serialNum %d",serialNum);
        return;
    }
    if (controllers[serialNum].connect){
        controllers[serialNum].setData(ori,pos);
    }
}

void ControllerManager::setConnect(int state){
    if(state & 1)
        controllers[1].connect = state>>1;
    else
        controllers[0].connect = state>>1;
    LOGI("ControllerManager::setConnect state %d, %d, %d",state,controllers[0].connect,controllers[1].connect);
}


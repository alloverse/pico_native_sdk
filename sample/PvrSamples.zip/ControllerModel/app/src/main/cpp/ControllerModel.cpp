//
// Created by Administrator on 2019/11/5.
//
#define STB_IMAGE_IMPLEMENTATION

#include "ControllerModel.h"
#include "logUtil.h"
#include "stb_image.h"


ControllerModel::ControllerModel(CVController* c) {
    controller = c;
    nearZ = 0.01f;
    farZ = 100.0f;
    fov0 = fov1 = 101.0f;
    offset = 0.06003f;
    scale = 0.01f;
}

void ControllerModel::init() {
    type = controller->serialNum;
    halfW = nearZ * tanf( fov0 * 0.5 * 3.1415926 /180 );
    halfH = nearZ * tanf( fov1 * 0.5 * 3.1415926 /180 );
    LOGI("FOV is %f , halfW is %f",fov0,halfW);

    mProjectionMatrix[0] = glm::frustum(-halfW,halfW,-halfH,halfH,nearZ,farZ);
    mProjectionMatrix[1] = glm::frustum(-halfW,halfW,-halfH,halfH,nearZ,farZ);

    bool objInit     = loadOBJ();
    bool shaderInit  = loadShader();
    bool textureInit = loadTexture();
    LOGI("ControllerModel init result: %d %d %d",objInit,shaderInit,textureInit);
}

bool ControllerModel::loadOBJ() {
    //load the model from obj file
    int nObjGeom;
    char objFile[1024];
    if(this->controller->serialNum == 0)
        sprintf(objFile, "%s/%s", ControllerManager::GetInstance()->externalFiles, "controller4Left.obj");
    else
        sprintf(objFile, "%s/%s", ControllerManager::GetInstance()->externalFiles, "controller4Right.obj");
    PvrGeometry::CreateFromObjFile(objFile, &mModel, nObjGeom);
    LOGI("%s, %d",objFile,nObjGeom);

    if(nObjGeom <= 0)
        return false;
    else
        return true;
}

bool ControllerModel::loadShader() {
    //load shader
    const char* VertSrc =
            "#version 300 es \n"
            "in vec3 position; \n"
            "in vec2 texcoord0; \n"

            "uniform mat4 projectionMatrix; \n"
            "uniform mat4 viewMatrix; \n"
            "uniform mat4 modelMatrix; \n"

            "out vec2 vTexcoord0; \n"

            "void main() \n"
            "{ \n"
            "    gl_Position = projectionMatrix * (viewMatrix * (modelMatrix * vec4(position, 1.0))); \n"
            "    vTexcoord0 = texcoord0; \n"
            "} \n";

    const char * FragSrc =
            "#version 300 es \n"
            "in vec2 vTexcoord0; \n"
            "uniform sampler2D srcTex; \n"
            "out vec4 outColor; \n"
            "void main() \n"
            "{ \n"
            "   vec2 coord = vec2(vTexcoord0.x, -vTexcoord0.y);"
            "    outColor = texture(srcTex, coord); \n"
            "} \n";

    mShader = new PvrShader();
    bool r = mShader->Initialize(1,&VertSrc,1,&FragSrc,"VertCtr","FragCtr");
    return r;
}

bool ControllerModel::loadTexture() {
    char texPath[1024];
    sprintf(texPath, "%s/%s", ControllerManager::GetInstance()->externalFiles, "controller4_idle.png");
    LOGI("%s",texPath);
    const char * texturePath = texPath;
    glGenTextures(1, &mModelTexture);
    glBindTexture(GL_TEXTURE_2D, mModelTexture);
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
    int width, height, nrChannels; // Will this nrChannels be 3 when GL_RGB, and 4 when GL_RGBA?
    unsigned char * textureData = stbi_load(texturePath, &width, &height, &nrChannels, 0);
    if(textureData) {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, textureData);
        glBindTexture( GL_TEXTURE_2D, 0 );
        stbi_image_free(textureData);
        LOGI("ControllerModel Succeed to load texture %s", texturePath);
        return true;
    } else {
        LOGE("ControllerModel load texture failed. use white color");
        unsigned char whiteData[4] = {255,255,255,255};
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, whiteData);
        glBindTexture( GL_TEXTURE_2D, 0 );
        return false;
    }
}


void ControllerModel::release() {
    glDeleteTextures(1,&mModelTexture);
    if (mModel!=NULL) {
        mModel->Destroy();
    }
    mShader->Destroy();
}


void ControllerModel::draw(int eye) {
    pvrPosef hmd = controller->mHMD;

    glm::fquat hmdOri = glm::fquat(
            hmd.Orientation.w,
            -hmd.Orientation.x,
            -hmd.Orientation.y,
            -hmd.Orientation.z
    );

    glm::vec3 hmdPos = glm::vec3(
            -hmd.Position.x,
            -hmd.Position.y,
            -hmd.Position.z
    );
    glm::mat4 hmdDiff[2];
    hmdDiff[0] = glm::translate( glm::mat4(1.0f), glm::vec3(-offset, 0.0f, 0.0f) );
    hmdDiff[1] = glm::translate( glm::mat4(1.0f), glm::vec3(offset, 0.0f, 0.0f) );

    glm::mat4 qMat = glm::mat4_cast(hmdOri);
    glm::mat4 pMat = glm::translate(glm::mat4(1.0f),hmdPos);

    glm::mat4 oMat[2];
    oMat[0] = glm::inverse(hmdDiff[0]);
    oMat[1] = glm::inverse(hmdDiff[1]);

    mViewMatrix[0] = oMat[0]*qMat*pMat;
    mViewMatrix[1] = oMat[1]*qMat*pMat;

    glm::mat4 model = controller->getMatrix();
    mModelMatrix = glm::scale(model, glm::vec3(scale, scale, scale));

    if (mShader->GetShaderId() == 0 || mModel == NULL) {
        return;
    }
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    mShader->Bind();
    mShader->SetUniformMat4("projectionMatrix", mProjectionMatrix[eye]);
    mShader->SetUniformMat4("viewMatrix", mViewMatrix[eye]);
    mShader->SetUniformMat4("modelMatrix", mModelMatrix);
    mShader->SetUniformSampler("srcTex", mModelTexture, GL_TEXTURE_2D, 0);
    mModel->Submit();
    mShader->Unbind();

    glDisable(GL_BLEND);
    LOGI("ControllerModel::draw end eye %d X", eye);
}

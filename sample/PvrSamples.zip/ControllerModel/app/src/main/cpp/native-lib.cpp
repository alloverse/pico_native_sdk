#include <jni.h>
#include <string>
#include "CVController.h"

extern "C"
JNIEXPORT jstring JNICALL
Java_com_picovr_controllermodel_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}

extern "C"
JNIEXPORT void JNICALL
Java_com_picovr_controllermodel_MainActivity_initControllerModel(JNIEnv *env, jobject thiz) {
    ControllerManager::GetInstance()->initAll();
}

extern "C"
JNIEXPORT void JNICALL
Java_com_picovr_controllermodel_MainActivity_releaseControllerModel(JNIEnv *env, jobject thiz) {
    ControllerManager::GetInstance()->releaseAll();
}

extern "C"
JNIEXPORT void JNICALL
Java_com_picovr_controllermodel_MainActivity_drawControllerModel(JNIEnv *env, jobject thiz, jint eyeType) {
    ControllerManager::GetInstance()->drawAll(eyeType);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_picovr_controllermodel_MainActivity_updateHMD(JNIEnv *env, jobject thiz,
                                                       jfloatArray orientation,
                                                       jfloatArray position ) {
//    int len_o = env->GetArrayLength(orientation);
//    int len_p = env->GetArrayLength(position);
//    if(len_o < 4 || len_p < 3)
//        return;

    jfloat* array_o = env->GetFloatArrayElements(orientation,JNI_FALSE);
    jfloat* array_p = env->GetFloatArrayElements(position,JNI_FALSE);
    pvrPosef posef;
    posef.Orientation.x = array_o[0];
    posef.Orientation.y = array_o[1];
    posef.Orientation.z = array_o[2];
    posef.Orientation.w = array_o[3];
    posef.Position.x = array_p[0];
    posef.Position.y = array_p[1];
    posef.Position.z = array_p[2];
    ControllerManager::GetInstance()->updateHMD(&posef);
    env->ReleaseFloatArrayElements(orientation,array_o,JNI_COMMIT);
    env->ReleaseFloatArrayElements(position,array_p,JNI_COMMIT);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_picovr_controllermodel_MainActivity_setData(JNIEnv *env, jobject thiz,
                                                     jint serial_num,
                                                     jfloatArray orientation,
                                                     jfloatArray position ) {
//    int len_o = env->GetArrayLength(orientation);
//    int len_p = env->GetArrayLength(position);
//    if(len_o < 4 || len_p < 3)
//        return;

    jfloat* array_o = env->GetFloatArrayElements(orientation,JNI_FALSE);
    jfloat* array_p = env->GetFloatArrayElements(position,JNI_FALSE);

    ControllerManager::GetInstance()->setData(serial_num,array_o,array_p);
    env->ReleaseFloatArrayElements(orientation,array_o,JNI_COMMIT);
    env->ReleaseFloatArrayElements(position,array_p,JNI_COMMIT);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_picovr_controllermodel_MainActivity_updateConnectState(JNIEnv *env, jobject thiz,
                                                                jint state) {
    ControllerManager::GetInstance()->setConnect(state);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_picovr_controllermodel_MainActivity_setExternalFilesPath(JNIEnv *env, jobject thiz,
                                                                  jstring path) {
    const char* str = env->GetStringUTFChars(path, JNI_FALSE);
    sprintf(ControllerManager::GetInstance()->externalFiles,"%s",str);

}
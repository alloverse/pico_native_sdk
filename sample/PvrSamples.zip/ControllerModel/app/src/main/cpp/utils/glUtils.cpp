//=============================================================================
// FILE: BoundaryUtils.cpp
// Author: Enoch.Liu
// Created on 2019-07-18
// Version: 0.1
// Description: Pick Shader and Geometry out of BoundarySystem
//==============================================================================
#include "glUtils.h"
#include <unistd.h>

#include <cstdlib>
#include <cstring>
#include <cassert>
#include <cmath>
#include <cstddef>
#include <cctype>
#include <sstream>
#include <fstream>
#include <glm/gtc/type_ptr.hpp>
#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "glm/gtc/quaternion.hpp"
#include "glm/gtc/type_ptr.hpp"
#include "glm/gtx/euler_angles.hpp"
#include "glm/gtx/transform.hpp"
#include "logUtil.h"

#define TINYOBJ_SSCANF_BUFFER_SIZE  (4096)

namespace PVR
{

#pragma region Geometry
PvrGeometry::PvrGeometry()
    : mVbId(0)
    , mIbId(0)
    , mVaoId(0)
    , mVertexCount(0)
    , mIndexCount(0)
{

}

bool PvrGeometry::Initialize(PvrProgramAttribute* pAttribs, int nAttribs,
                             unsigned int* pIndices, int nIndices,
                             const void* pVertexData, int bufferSize, int nVertices)
{
    GLint defaultArrayBuffer = 0;
    GLint defaultVAO = 0;
    glGetIntegerv( GL_ARRAY_BUFFER_BINDING, &defaultArrayBuffer );
    glGetIntegerv( GL_VERTEX_ARRAY_BINDING, &defaultVAO );
    //LOGI("GGGG PvrGeometry::Initialize GL_ARRAY_BUFFER_BINDING = %d", defaultArrayBuffer);
    //LOGI("GGGG PvrGeometry::Initialize GL_VERTEX_ARRAY_BINDING = %d", defaultVAO);

    //Create the VAO
    GL(glGenVertexArrays( 1, &mVaoId ));
    GL(glBindVertexArray( mVaoId ));

    //Create the VBO
    GL(glGenBuffers( 1, &mVbId));
    GL(glBindBuffer( GL_ARRAY_BUFFER, mVbId ));
    GL(glBufferData( GL_ARRAY_BUFFER, bufferSize, pVertexData, GL_STATIC_DRAW));

    //Create the Index Buffer
    GL(glGenBuffers( 1, &mIbId));
    GL(glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, mIbId ));
    GL(glBufferData( GL_ELEMENT_ARRAY_BUFFER, nIndices * sizeof(unsigned int), pIndices, GL_STATIC_DRAW));

    for ( int i = 0; i < nAttribs; i++ )
    {
        GL(glEnableVertexAttribArray( pAttribs[i].index ));
        GL(glVertexAttribPointer(pAttribs[i].index, pAttribs[i].size,
                                 pAttribs[i].type, pAttribs[i].normalized,
                                 pAttribs[i].stride, (void*)(unsigned long long)(pAttribs[i].offset)));
    }

    GL(glBindVertexArray( defaultVAO ));
    GL(glBindBuffer( GL_ARRAY_BUFFER, defaultArrayBuffer ));


    mVertexCount = nVertices;
    mIndexCount = nIndices;
    return true;
}

void PvrGeometry::Update(const void* pVertexData, int bufferSize, int nVertices)
{
    GL(glBindBuffer(GL_ARRAY_BUFFER, mVbId));
    GL(glBufferData(GL_ARRAY_BUFFER, bufferSize, pVertexData, GL_STATIC_DRAW));
    GL(glBindBuffer(GL_ARRAY_BUFFER, 0));
}

void PvrGeometry::Destroy()
{
    GL(glDeleteBuffers( 1, &mIbId ));
    GL(glDeleteBuffers( 1, &mVbId ));

    mVbId = 0;
    mIbId = 0;
    mVaoId = 0;
    mVertexCount = 0;
    mIndexCount = 0;
}

void PvrGeometry::Submit()
{
    GL( glBindVertexArray( mVaoId ) );
    GL( glDrawElements(GL_TRIANGLES, mIndexCount, GL_UNSIGNED_INT, NULL) );
    GL( glBindVertexArray( 0 ) );
}

void PvrGeometry::Submit(PvrProgramAttribute* pAttribs, int nAttribs)
{
    GL(glBindBuffer(GL_ARRAY_BUFFER, mVbId));

    for (int i = 0; i < nAttribs; i++)
    {
        GL(glEnableVertexAttribArray(pAttribs[i].index));
        GL(glVertexAttribPointer(pAttribs[i].index, pAttribs[i].size,
            pAttribs[i].type, pAttribs[i].normalized,
            pAttribs[i].stride, (void*)(unsigned long long)(pAttribs[i].offset)));
    }

    GL(glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mIbId));

    GL(glDrawElements(GL_TRIANGLES, mIndexCount, GL_UNSIGNED_INT, NULL));


    for (int i = 0; i < nAttribs; i++)
    {
        GL(glDisableVertexAttribArray(pAttribs[i].index));
    }

    GL(glBindBuffer(GL_ARRAY_BUFFER, 0));
    GL(glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0));

}


int PvrGeometry::CreateFromObjFile(const char* pObjFilePath, PvrGeometry** pOutGeometry, int& outNumGeometry)
{
    std::vector<tinyobj::shape_t>       shapes;
    std::vector<tinyobj::material_t>    materials;
    std::string err = tinyobj::LoadObj(shapes, materials, pObjFilePath, NULL);
    if (!err.empty())
    {
        LOGI("CreateFromObjFile : %s", err.c_str());
        *pOutGeometry = NULL;
        outNumGeometry = 0;
        return -1;
    }

    PvrProgramAttribute attribs[3];

    *pOutGeometry = new PvrGeometry[shapes.size()];
    int size = shapes.size();
    LOGI("Found %d shapes", size);

    for (size_t i = 0; i < shapes.size(); i++)
    {
        int vertexSize = 0;
        int nAttribs = 0;

        if (shapes[i].mesh.positions.size() == 0 ||
            shapes[i].mesh.normals.size() == 0)
        {
            LOGI("OBJ must contain at least positions and normals");
            *pOutGeometry = NULL;
            outNumGeometry = 0;
            return -1;
        }

        nAttribs = 3;
        vertexSize = 8 * sizeof(float);

        attribs[0].index = kPosition;
        attribs[0].size = 3;
        attribs[0].type = GL_FLOAT;
        attribs[0].normalized = false;
        attribs[0].stride = vertexSize;
        attribs[0].offset = 0;

        attribs[1].index = kNormal;
        attribs[1].size = 3;
        attribs[1].type = GL_FLOAT;
        attribs[1].normalized = false;
        attribs[1].stride = vertexSize;
        attribs[1].offset = 3 * sizeof(float);

        attribs[2].index = kTexcoord0;
        attribs[2].size = 2;
        attribs[2].type = GL_FLOAT;
        attribs[2].normalized = false;
        attribs[2].stride = vertexSize;
        attribs[2].offset = 6 * sizeof(float);

        float* pVbData = new float[vertexSize * shapes[i].mesh.positions.size()];
        int vbIndex = 0;
        for (size_t j = 0; j < shapes[i].mesh.positions.size() / 3; j++)
        {
            pVbData[vbIndex++] = shapes[i].mesh.positions[3 * j + 0];
            pVbData[vbIndex++] = shapes[i].mesh.positions[3 * j + 1];
            pVbData[vbIndex++] = shapes[i].mesh.positions[3 * j + 2];

            pVbData[vbIndex++] = shapes[i].mesh.normals[3 * j + 0];
            pVbData[vbIndex++] = shapes[i].mesh.normals[3 * j + 1];
            pVbData[vbIndex++] = shapes[i].mesh.normals[3 * j + 2];

            pVbData[vbIndex++] = shapes[i].mesh.texcoords[2 * j + 0];
            pVbData[vbIndex++] = shapes[i].mesh.texcoords[2 * j + 1];
        }

        pOutGeometry[i]->Initialize(&attribs[0], nAttribs,
            &shapes[i].mesh.indices[0], shapes[i].mesh.indices.size(),
            (const void*)pVbData, vertexSize * shapes[i].mesh.positions.size(), shapes[i].mesh.positions.size());

        LOGI("OBJ Geom Initialized, idx count:%d, pos count:%d", shapes[i].mesh.indices.size(), shapes[i].mesh.positions.size());
        delete[] pVbData;
    }

    outNumGeometry = shapes.size();
    return 0;
}
#pragma endregion


#pragma region Shader
static PvrAttribute gPvrDefaultAttributes[] =
{
    { kPosition, "position"},
    { kNormal, "normal"},
    { kColor, "color"},
    { kTexcoord0, "texcoord0"},
    { kTexcoord1, "texcoord1"}
};

bool IsSamplerType(unsigned int type)
{
    if( type == GL_SAMPLER_2D ||
        type == GL_SAMPLER_2D_ARRAY ||
        type == GL_SAMPLER_EXTERNAL_OES ||
        type == GL_SAMPLER_3D ||
        type == GL_SAMPLER_CUBE )
    {
        return true;
    }
    return false;
}

unsigned int PvrShader::gCurrentBoundShader = 0;

PvrShader::PvrShader()
    : mShaderId(0)
    , mVsId(0)
    , mFsId(0)
{
    mRefCount = 0;
    mUniformMap.Init(32);

    mDefaultActiveTexture = 0;
    mDefaultTexture0Tex = 0;
    mDefaulProgram = 0;
}

bool PvrShader::Initialize(int numVertStrings, const char** pVertSrc, int numFragStrings, const char** pFragSrc, const char* pVertDbgName, const char* pFragDbgName)
{
    static char errMsg[4096];
    int result;

    bool fLOGIShaderInit = false;

    if (fLOGIShaderInit)
    {
        if (pVertDbgName && pFragDbgName)
            LOGI("Loading Shader: %s <=> %s", pVertDbgName, pFragDbgName);
        else
            LOGI("Loading Shader: Unknown <=> Unknown");
    }

    mVsId = GL(glCreateShader( GL_VERTEX_SHADER ));
    GL(glShaderSource(mVsId, numVertStrings, pVertSrc, 0));
    GL(glCompileShader( mVsId ));
    GL(glGetShaderiv( mVsId, GL_COMPILE_STATUS, &result ));
    if( result == GL_FALSE )
    {
        errMsg[0] = 0;
        GL(glGetShaderInfoLog( mVsId, sizeof(errMsg), 0, errMsg));
        if (pVertDbgName)
            LOGI("%s : %s\n", pVertDbgName, errMsg);
        else
            LOGI("Compile Error : %s\n", errMsg);
        return false;
    }

    mFsId = GL(glCreateShader( GL_FRAGMENT_SHADER ));
    GL(glShaderSource(mFsId, numFragStrings, pFragSrc, 0));
    GL(glCompileShader( mFsId ));
    GL(glGetShaderiv( mFsId, GL_COMPILE_STATUS, &result ));
    if( result == GL_FALSE )
    {
        errMsg[0] = 0;
        GL(glGetShaderInfoLog( mFsId, sizeof(errMsg), 0, errMsg));
        if (pFragDbgName)
            LOGI("%s : %s\n", pFragDbgName, errMsg);
        else
            LOGI("Compile Error : %s\n", errMsg);
        return false;
    }

    mShaderId = GL(glCreateProgram());
    GL(glAttachShader( mShaderId, mVsId ));
    GL(glAttachShader( mShaderId, mFsId ));

    for ( unsigned int i = 0; i < sizeof( gPvrDefaultAttributes ) / sizeof( gPvrDefaultAttributes[0] ); i++ )
    {
        if (fLOGIShaderInit) LOGI("Shader %d: %s => %d", mShaderId, gPvrDefaultAttributes[i].name, gPvrDefaultAttributes[i].location);
        GL(glBindAttribLocation(mShaderId, gPvrDefaultAttributes[i].location, gPvrDefaultAttributes[i].name));
    }

    GL(glLinkProgram( mShaderId ));
    GL(glGetProgramiv( mShaderId, GL_LINK_STATUS, &result));
    if( result == GL_FALSE )
    {
        errMsg[0] = 0;
        GL(glGetProgramInfoLog( mShaderId, sizeof(errMsg), 0, errMsg));
        if (pVertDbgName && pFragDbgName)
            LOGI("Link (%s,%s) : %s\n", pVertDbgName, pFragDbgName, errMsg);
        else
            LOGI("Link Error : %s\n", errMsg);
        return false;
    }

    if (fLOGIShaderInit) LOGI("    Shader (Handle = %d) Linked: %s <=> %s", mShaderId, pVertDbgName, pFragDbgName);

    int curTextureUnit = 0;
    int nActiveUniforms;
    GL(glGetProgramiv( mShaderId, GL_ACTIVE_UNIFORMS, &nActiveUniforms ));
    if (fLOGIShaderInit) LOGI("    Shader (Handle = %d) has %d active uniforms", mShaderId, nActiveUniforms);

    GL(glGetIntegerv(GL_CURRENT_PROGRAM, &mDefaulProgram));
    GL( glUseProgram( mShaderId ) );

    char nameBuffer[MAX_UNIFORM_NAME_LENGTH];
    for( int i=0; i < nActiveUniforms; i++ )
    {
        int uniformNameLength, uniformSize;
        GLenum uniformType;
        GL(glGetActiveUniform( mShaderId, i, MAX_UNIFORM_NAME_LENGTH - 1, &uniformNameLength, &uniformSize, &uniformType, &nameBuffer[0]));
        nameBuffer[uniformNameLength] = 0;
        unsigned int location = GL(glGetUniformLocation( mShaderId, nameBuffer ));

        PvrUniform uniform;
        uniform.location = location;
        uniform.type = uniformType;
        strncpy( uniform.name, nameBuffer, MAX_UNIFORM_NAME_LENGTH );

        if (IsSamplerType(uniformType))
        {
            GL(glUniform1i( location, curTextureUnit));
            uniform.textureUnit = curTextureUnit++;
            if (fLOGIShaderInit) LOGI("        Uniform (%s) is a texture in unit %d", nameBuffer, uniform.textureUnit);
        }
        else
        {
            uniform.textureUnit = 0;
            if (fLOGIShaderInit) LOGI("        Uniform (%s) is NOT a texture in unit %d", nameBuffer, uniform.textureUnit);
        }

        if (fLOGIShaderInit) LOGI("    Inserting (%s) into uniform map...", nameBuffer);
        mUniformMap.Insert( &nameBuffer[0], uniform );
    }

    GL( glUseProgram( mDefaulProgram ) );

    // Always want this LOGI message
    if (true || fLOGIShaderInit)
    {
        if (pVertDbgName && pFragDbgName)
            LOGI("Loaded Shader (%d): %s <=> %s", mShaderId, pVertDbgName, pFragDbgName);
        else
            LOGI("Loaded Shader (%d): Unknown <=> Unknown", mShaderId);
    }

    return true;
}

void PvrShader::Destroy()
{
    if (mShaderId != 0)
        GL(glDeleteProgram(mShaderId));

    if (mVsId != 0)
        GL(glDeleteShader(mVsId));

    if (mFsId != 0)
        GL(glDeleteShader(mFsId));

    mShaderId = 0;
    mVsId = 0;
    mFsId = 0;

    mDefaultActiveTexture = 0;
    mDefaultTexture0Tex = 0;
    mDefaulProgram = 0;
}

void PvrShader::Bind()
{
    // Here is the problem: gCurrentBoundShader is global across all threads!
    // This means there are collisions between threads that are not really collisions.
    // Therefore we can't check this for the spacewarp branch :(
    // if (gCurrentBoundShader != 0)
    // {
    //     LOGIE("Warning! (ThreadID = 0x%08x) Shader (Handle = %d) is already bound while binding new shader (Handle = %d)", gettid(), gCurrentBoundShader, mShaderId);
    // }

    if (mRefCount != 0)
    {
        LOGI("Warning! (ThreadID = 0x%08x) Shader (Handle = %d) is being bound without being unbound. Bind count = %d", gettid(), mShaderId, mRefCount);
    }
    mRefCount = mRefCount + 1;

    gCurrentBoundShader = mShaderId;

    // LOGIE("Binding Shader (Handle = %d). Bind count = %d", mShaderId, mRefCount);
    GL(glGetIntegerv(GL_CURRENT_PROGRAM, &mDefaulProgram));
    GL( glUseProgram( mShaderId ) );
}

void PvrShader::Unbind()
{
    if (mRefCount == 0)
    {
        LOGI("Warning! Shader (Handle = %d) is being unbound without being bound.", mShaderId);
    }
    else
    {
        mRefCount = mRefCount - 1;
    }


    bool bBindTexture = false;
    UniformMap::Iterator uniformIter = mUniformMap.GetIterator();
    while (!uniformIter.End())
    {
        PvrUniform oneEntry = uniformIter.Current();

        if (IsSamplerType(oneEntry.type))
        {
            bBindTexture = true;
            break;
        }

        uniformIter.Next();
    }

    if(bBindTexture == true)
    {
        GL(glBindSampler(mBindTextureUnit, mDefaultTexture0Sampler));
        GL(glBindTexture(GL_TEXTURE_2D, mDefaultTexture0Tex));
        GL(glActiveTexture( mDefaultActiveTexture ));
        mDefaultActiveTexture = 0;
        mDefaultTexture0Tex = 0;
        mDefaultTexture0Sampler = 0;
    }


    gCurrentBoundShader = 0;

    // LOGIE("Unbinding Shader (Handle = %d). Bind count = %d", mShaderId, mRefCount);
    GL(glUseProgram(mDefaulProgram));
    mDefaulProgram = 0;

    // // Unbind all samplers
    // //UniformMap::Iterator uniformIter = mUniformMap.GetIterator();
    // while (!uniformIter.End())
    // {
    //     PvrUniform oneEntry = uniformIter.Current();

    //     if (IsSamplerType(oneEntry.type))
    //     {
    //         GL(glBindSampler(oneEntry.textureUnit, 0));
    //     }

    //     uniformIter.Next();
    // }
}

void PvrShader::SetUniformMat2(const char* name, glm::mat2& matrix)
{
    PvrUniform  uniform;
    if( mUniformMap.Find( name, &uniform))
    {
        SetUniformMat2(uniform.location, matrix);
    }
}

void PvrShader::SetUniformMat2(int location, glm::mat2& matrix)
{
    GL(glUniformMatrix2fv(location, 1, GL_FALSE, glm::value_ptr(matrix)));
}

void PvrShader::SetUniformMat2fv(const char* name, unsigned int count, float *pData)
{
    PvrUniform  uniform;
    if (mUniformMap.Find(name, &uniform))
    {
        SetUniformMat2fv(uniform.location, count, pData);
    }
}

void PvrShader::SetUniformMat2fv(int location, unsigned int count, float *pData)
{
    GL(glUniformMatrix2fv(location, count, GL_FALSE, pData));
}

void PvrShader::SetUniformMat3(const char* name, glm::mat3& matrix)
{
    PvrUniform  uniform;
    if (mUniformMap.Find(name, &uniform))
    {
        SetUniformMat3(uniform.location, matrix);
    }
}

void PvrShader::SetUniformMat3(int location, glm::mat3& matrix)
{
    GL(glUniformMatrix3fv(location, 1, GL_FALSE, glm::value_ptr(matrix)));
}

void PvrShader::SetUniformMat4(const char* name, glm::mat4& matrix)
{
    PvrUniform  uniform;
    if( mUniformMap.Find( name, &uniform ) )
    {
        SetUniformMat4(uniform.location, matrix);
    }
}

void PvrShader::SetUniformMat4(int location, glm::mat4& matrix)
{
    GL(glUniformMatrix4fv(location, 1, GL_FALSE, glm::value_ptr(matrix)));
}

void PvrShader::SetUniformMat4fv(const char* name, unsigned int count, float *pData)
{
    PvrUniform  uniform;
    if (mUniformMap.Find(name, &uniform))
    {
        SetUniformMat4fv(uniform.location, count, pData);
    }
}
void PvrShader::SetUniformMat4fv(int location, unsigned int count, float *pData)
{
    GL(glUniformMatrix4fv(location, count, GL_FALSE, pData));
}

void PvrShader::SetUniformVec4(const char* name, glm::vec4& vector)
{
    PvrUniform uniform;
    if(mUniformMap.Find( name, &uniform))
    {
        SetUniformVec4(uniform.location, vector);
    }
}

void PvrShader::SetUniformVec4(int location, glm::vec4& vector)
{
    GL(glUniform4fv(location, 1, glm::value_ptr(vector)));
}

void PvrShader::SetUniformVec3(const char* name, glm::vec3& vector)
{
    PvrUniform uniform;
    if (mUniformMap.Find(name, &uniform))
    {
        SetUniformVec3(uniform.location, vector);
    }
}

void PvrShader::SetUniformVec3(int location, glm::vec3& vector)
{
    GL(glUniform3fv(location, 1, glm::value_ptr(vector)));
}

void PvrShader::SetUniformVec2(const char* name, glm::vec2& vector)
{
    PvrUniform uniform;
    if (mUniformMap.Find(name, &uniform))
    {
        SetUniformVec2(uniform.location, vector);
    }
}

void PvrShader::SetUniformVec2(int location, glm::vec2& vector)
{
    GL(glUniform2fv(location, 1, glm::value_ptr(vector)));
}

void PvrShader::SetUniform1ui(const char* name, unsigned int value)
{
    PvrUniform uniform;
    if (mUniformMap.Find(name, &uniform))
    {
        SetUniform1ui(uniform.location, value);
    }
}

void PvrShader::SetUniform1ui(int location, unsigned int value)
{
    GL(glUniform1ui(location, value));
}

void PvrShader::SetUniformSampler(const char* name, unsigned int samplerId, unsigned int samplerType, GLuint samplerObjId)
{
    bool fLOGITextureInfo = false;

    PvrUniform uniform;
    if(mUniformMap.Find( name, &uniform))
    {
        // It turns out the driver does not handle samplers on image textures :(
        // if (samplerObjId != 0 && samplerType != GL_TEXTURE_EXTERNAL_OES)
        // {
        //     // LOGII("Binding sampler %d to unit %d", samplerObjId, uniform.textureUnit);
        //     GL(glBindSampler(uniform.textureUnit, samplerObjId));
        // }

        GL(glGetIntegerv(GL_ACTIVE_TEXTURE, &mDefaultActiveTexture));
        GL(glActiveTexture(GL_TEXTURE0 + uniform.textureUnit));

        GL(glGetIntegerv(GL_TEXTURE_BINDING_2D, &mDefaultTexture0Tex));
        GL(glGetIntegerv(GL_SAMPLER_BINDING, &mDefaultTexture0Sampler));

        mBindTextureUnit = uniform.textureUnit;
        GL(glBindSampler(uniform.textureUnit, samplerObjId));
        GL(glBindTexture(samplerType, samplerId));
    }
}
#pragma endregion // region Shader

} // namespace PVR
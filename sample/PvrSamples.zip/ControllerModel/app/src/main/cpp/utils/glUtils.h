//=============================================================================
// FILE: BoundaryUtils.h
// Author: Enoch.Liu
// Created on 2019-07-18
// Version: 0.1
// Description: Pick Geometry and Shader out of BoundarySystem
//==============================================================================

#ifndef PVR_BOUNDARYUTILS_H
#define PVR_BOUNDARYUTILS_H
#include "tiny_obj_loader.h"
#include <vector>
#include <string>
#include <map>
#include <stdlib.h>

#include <GLES3/gl3.h>
#include <android/log.h>
#include "pvrHashTable.h"

#include "glm/glm.hpp"
#include <glm/detail/type_vec.hpp>
#include <glm/detail/type_mat.hpp>

#define MAX_UNIFORM_NAME_LENGTH 64

#ifndef GL_TEXTURE_EXTERNAL_OES
#define GL_TEXTURE_EXTERNAL_OES           0x8D65
#endif

#ifndef GL_SAMPLER_EXTERNAL_OES
#define GL_SAMPLER_EXTERNAL_OES           0x8D66
#endif

namespace PVR
{

#pragma region Geometry
struct PvrProgramAttribute
{
    unsigned int    index;
    int             size;
    unsigned int    type;
    bool            normalized;
    int             stride;
    int             offset;
};

class PvrGeometry
{
public:
    PvrGeometry();

    bool Initialize(PvrProgramAttribute* pAttribs, int nAttribs,
                    unsigned int* pIndices, int nIndices,
                    const void* pVertexData, int bufferSize, int nVertices);

    void Update(const void* pVertexData, int bufferSize, int nVertices);

    void Destroy();
    void Submit();
    void Submit(PvrProgramAttribute* pAttribs, int nAttribs);

    static int CreateFromObjFile(const char* pObjFilePath, PvrGeometry** pOutGeometry, int& outNumGeometry);

    unsigned int GetVbId() { return mVbId; }
    unsigned int GetIbId() { return mIbId; }
    unsigned int GetVaoId() { return mVaoId; }
    int GetVertexCount() { return mVertexCount; }
    int GetIndexCount() { return mIndexCount; }

private:
    unsigned int    mVbId;
    unsigned int    mIbId;
    unsigned int    mVaoId;
    int             mVertexCount;
    int             mIndexCount;
};
#pragma endregion // Geometry

#pragma region Shader
enum PvrAttributeLocation
{
    kPosition = 0,
    kNormal = 1,
    kColor = 2,
    kTexcoord0 = 3,
    kTexcoord1 = 4
} ;

struct PvrAttribute
{
    PvrAttributeLocation    location;
    const char*             name;
};

struct PvrUniform
{
    unsigned int location;
    GLenum       type;
    char         name[MAX_UNIFORM_NAME_LENGTH];
    unsigned int textureUnit;
};

class PvrShader
{
public:
    PvrShader();

    bool Initialize(int numVertStrings, const char** pVertSrc, int numFragStrings, const char** pFragSrc, const char* pVertDbgName = NULL, const char* pFragDbgName = NULL);
    void Destroy();
    void Bind();
    void Unbind();

    void SetUniformMat2(const char* name, glm::mat2& matrix);
    void SetUniformMat2(int location, glm::mat2& matrix);
    void SetUniformMat2fv(const char* name, unsigned int count, float *pData);
    void SetUniformMat2fv(int location, unsigned int count, float *pData);
    void SetUniformMat3(const char* name, glm::mat3& matrix);
    void SetUniformMat3(int location, glm::mat3& matrix);
    void SetUniformMat4(const char* name, glm::mat4& matrix);
    void SetUniformMat4(int location, glm::mat4& matrix);
    void SetUniformMat4fv(const char* name, unsigned int count, float *pData);
    void SetUniformMat4fv(int location, unsigned int count, float *pData);
    void SetUniformVec4(const char* name, glm::vec4& vector);
    void SetUniformVec4(int location, glm::vec4& vector);
    void SetUniformVec3(const char* name, glm::vec3& vector);
    void SetUniformVec3(int location, glm::vec3& vector);
    void SetUniformVec2(const char* name, glm::vec2& vector);
    void SetUniformVec2(int location, glm::vec2& vector);
    void SetUniform1ui(const char* name, unsigned int value);
    void SetUniform1ui(int location, unsigned int value);
    void SetUniformSampler(const char* name, unsigned int samplerId, unsigned int samplerType, GLuint samplerObjId);

    unsigned int GetShaderId() { return mShaderId;  }

private:
    static unsigned int gCurrentBoundShader;

    typedef HashTable<unsigned int, PvrUniform, DjB2Hash> UniformMap;
    typedef HashTable<unsigned int, unsigned int, DjB2Hash> SamplerMap;

    unsigned int    mRefCount;

    unsigned int    mShaderId;
    unsigned int    mVsId;
    unsigned int    mFsId;
    UniformMap      mUniformMap;

    GLint           mDefaultActiveTexture;
    GLint           mDefaultTexture0Tex;
    GLint           mDefaultTexture0Sampler;
    unsigned int    mBindTextureUnit;
    GLint           mDefaulProgram;
};
#pragma endregion // Shader
} // namespace PVR
#endif // PVR_BOUNDARYUTILS_H
//
// Created by Administrator on 2019/11/7.
//

#ifndef PICOSDK_MOBILE_CORELIB_CV2CONTROLLER_H
#define PICOSDK_MOBILE_CORELIB_CV2CONTROLLER_H

#include "glm/gtx/simd_quat.hpp"
#include "glm/glm.hpp"

typedef struct pvrQuatf_
{
    float x, y, z, w;
} pvrQuatf;

typedef struct pvrVector3f_
{
    float x, y, z;
} pvrVector3f;

// Position and orientation together.
typedef struct pvrPosef_
{
    pvrQuatf	Orientation;
    pvrVector3f	Position;
} pvrPosef;

class ControllerModel;

class CVController{
public:
    ControllerModel* ctrModel;

    int serialNum;
    bool connect=true;
    glm::fquat orientation= glm::angleAxis(0.0f,glm::vec3(0,1,0));
    glm::vec3 position    = glm::vec3(0,0,0);
    glm::vec3 rayPoint;
    glm::vec3 intersectPoint;
    bool intersect;
    pvrPosef mHMD;

    glm::vec3 center;
    glm::vec3 LT;
    glm::vec3 RT;
    glm::vec3 LB;
    glm::vec3 RB;

    CVController();
    ~CVController();
    void init();
    void release();
    void setData(float* ori,float* pos);
    void setHmdSensor(pvrPosef sensor);
    glm::mat4 getMatrix();
};

class ControllerManager{
private:
    CVController* controllers;
    static ControllerManager* mInstance;
    ControllerManager();
public:
    static ControllerManager* GetInstance()
    {
        if (!mInstance)
            mInstance = new ControllerManager();
        return mInstance;
    }
    char externalFiles[1024];
    void initAll();
    void releaseAll();
    void drawAll(int eye);
    void updateHMD(pvrPosef* hmd);
    void setData(int serialNum, float* ori, float* pos);
    void setConnect(int state);
};
#endif //PICOSDK_MOBILE_CORELIB_CV2CONTROLLER_H

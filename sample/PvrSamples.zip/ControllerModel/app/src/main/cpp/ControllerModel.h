//
// Created by Administrator on 2019/11/5.
//

#ifndef PICOSDK_MOBILE_CORELIB_CONTROLLERMODEL_H
#define PICOSDK_MOBILE_CORELIB_CONTROLLERMODEL_H

#include "glm/glm.hpp"
#include "glm/ext.hpp"
#include "CVController.h"
#include <GLES3/gl3.h>
#include <utils/glUtils.h>

using namespace PVR;

class ControllerModel{
private:
    CVController* controller;

    float fov0;
    float fov1;
    float nearZ;
    float farZ;
    float halfW;
    float halfH;
    float offset;
    float scale;
    int type;
    PvrGeometry *mModel=NULL;
    PvrShader *mShader;
    GLuint mModelTexture;
    glm::mat4 mModelMatrix;
    glm::mat4 mViewMatrix[2];
    glm::mat4 mProjectionMatrix[2];

    GLuint mLineProgram;
    GLuint mPointProgram;

    bool loadOBJ();
    bool loadShader();
    bool loadTexture();
public:
    ControllerModel(CVController* c);
    ~ControllerModel();
    void init();
    void draw(int eye);
    void release();
};

#endif //PICOSDK_MOBILE_CORELIB_CONTROLLERMODEL_H

package com.picovr.controllermodel;


import android.app.Activity;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;

import com.picovr.cvclient.CVController;
import com.picovr.cvclient.CVControllerListener;
import com.picovr.cvclient.CVControllerManager;
import com.picovr.vractivity.Eye;
import com.picovr.vractivity.HmdState;
import com.picovr.vractivity.RenderInterface;
import com.picovr.vractivity.VRActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import androidx.core.app.ActivityCompat;

public class MainActivity extends VRActivity implements RenderInterface {

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();
    public native void initControllerModel();
    public native void releaseControllerModel();
    public native void drawControllerModel(int eyeType);
    public native void updateHMD(float[] orientation, float[] position);
    public native void setData(int serialNum, float[] orientation, float[] position);
    public native void updateConnectState(int state);
    public native void setExternalFilesPath(String path);

    // init cv service
    private CVController leftController;
    private CVController rightController;
    private CVControllerManager cvManager;
    private CVControllerListener cvListener = new CVControllerListener() {
        @Override
        public void onBindSuccess() {        }

        @Override
        public void onBindFail() {        }

        @Override
        public void onThreadStart() {
            leftController = cvManager.getMainController();
            rightController = cvManager.getSubController();
            updateConnectState(leftController.getConnectState() << 1 | leftController.getSerialNum());
            updateConnectState(rightController.getConnectState() << 1 | rightController.getSerialNum());

        }

        @Override
        public void onConnectStateChanged(int i, int i1) {
            updateConnectState(leftController.getConnectState() << 1 | leftController.getSerialNum());
            updateConnectState(rightController.getConnectState() << 1 | rightController.getSerialNum());
        }

        @Override
        public void onMainControllerChanged(int i) {        }

        @Override
        public void onChannelChanged(int i, int i1) {        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN
                        | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
                        | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        super.onCreate(savedInstanceState);

        cvManager = new CVControllerManager(this.getApplicationContext());
        cvManager.setListener(cvListener);
        leftController = cvManager.getMainController();
        rightController = cvManager.getSubController();
        verifyStoragePermissions(this);
        copyAssetsToExternal();
    }

    @Override
    protected void onResume(){
        super.onResume();
        cvManager.bindService();
    }

    @Override
    protected void onPause(){
        cvManager.unbindService();
        super.onPause();
    }

    @Override
    public void onFrameBegin(HmdState hmdState) {
        Log.d(this.getPackageName(),"onFrameBegin");
        updateHMD(hmdState.getOrientation(),hmdState.getPos());
        setData(leftController.getSerialNum(),
                leftController.getOrientation(),
                leftController.getPosition()
        );
        setData(rightController.getSerialNum(),
                rightController.getOrientation(),
                rightController.getPosition()
        );
    }

    @Override
    public void onDrawEye(Eye eye) {
        drawControllerModel(eye.getType());
    }

    @Override
    public void onFrameEnd() {

    }

    @Override
    public void onTouchEvent() {

    }

    @Override
    public void onRenderPause() {

    }

    @Override
    public void onRenderResume() {

    }

    @Override
    public void onRendererShutdown() {
        releaseControllerModel();
    }

    @Override
    public void initGL(int i, int i1) {
        initControllerModel();
    }

    @Override
    public void renderEventCallBack(int i) {

    }

    @Override
    public void surfaceChangedCallBack(int i, int i1) {

    }

    /*
     * copy the Assets from assets/raw to app's external file dir
     */
    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            "android.permission.READ_EXTERNAL_STORAGE",
            "android.permission.WRITE_EXTERNAL_STORAGE" };

    public static final  String ASSETS_SUB_FOLDER_NAME = "raw";
    public static final int BUFFER_SIZE = 1024;

    public static void verifyStoragePermissions(Activity activity) {
        try {
            int permission = ActivityCompat.checkSelfPermission(activity,
                    "android.permission.WRITE_EXTERNAL_STORAGE");
            if (permission != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(activity, PERMISSIONS_STORAGE,REQUEST_EXTERNAL_STORAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void copyAssetsToExternal() {
        AssetManager assetManager = getAssets();
        String[] files = null;
        try {
            InputStream in = null;
            OutputStream out = null;

            files = assetManager.list(ASSETS_SUB_FOLDER_NAME);
            for (int i = 0; i < files.length; i++) {
                in = assetManager.open(ASSETS_SUB_FOLDER_NAME + "/" + files[i]);
                String outDir = getExternalFilesDir(null).toString() + "/";

                File outFile = new File(outDir, files[i]);
                out = new FileOutputStream(outFile);
                copyFile(in, out);
                in.close();
                in = null;
                out.flush();
                out.close();
                out = null;
            }
        } catch (IOException e) {
            Log.e(this.getPackageName(), "Failed to get asset file list.", e);
        }
        File file = getExternalFilesDir(null);
        Log.d(this.getPackageName(), "file:" + file.toString());
        setExternalFilesPath(file.toString());
    }
    /*
     * read file from InputStream and write to OutputStream.
     */
    private void copyFile(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[BUFFER_SIZE];
        int read;
        while ((read = in.read(buffer)) != -1) {
            out.write(buffer, 0, read);
        }
    }

}
